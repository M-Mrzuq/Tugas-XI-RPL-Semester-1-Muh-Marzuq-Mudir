document.write("saya sedang mencoba belajar Java Script");
console.log("Ngapain Dilihat?");
// alert("Have Good Night Nelaa <3");
var hasil = document.getElementById("hasil-output");
hasil.innerHTML = "<p>Aku suka Javascript</p>";

var name = "Petani Kode";
var visitorCount = 50322;
var isActive = true;
var url = "https://www.petanikode.com";
// menampilkan variabel ke jendela dialog (alert)
alert("Selamat datang di " + name);
    
// menampilkan variabel ke dalam HTML
document.write("Nama Situs: " + name + "<br>");
document.write("Jumlah Pengunjung: " + visitorCount + "<br>");
document.write("Status Aktif: " + isActive + "<br>");
document.write("Alamat URL: " + url + "<br>");

