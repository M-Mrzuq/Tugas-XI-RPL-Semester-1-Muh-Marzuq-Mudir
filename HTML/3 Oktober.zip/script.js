var hasil = document.getElementById("hasil-output");
hasil.innerHTML = "<h2>Biodata</h2> <p>Nama : Muh Marzuq Mudir</p> <p>Kelas : XI RPL</p>";